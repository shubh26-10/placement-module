﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class BranchAdd : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
        }
               protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BranchMaster b = new BranchMaster();
            b.branch_id = db.BranchMasters.Max(o => o.branch_id) + 1;
            b.branch_code = Convert.ToInt32(txtBranchCode.Text.Trim());
            b.branch_name = txtBranchName.Text.Trim();

            db.BranchMasters.Add(b);
            db.SaveChanges();

            Response.Redirect("/BranchList.aspx");
        }
        }
}