﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class BranchEdit : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        int _branchid = 0;
        protected void Page_Load(object sender, EventArgs e)
        {


            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }

            if (Request.QueryString["branchid"] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            else
            {
                if (!int.TryParse(Request.QueryString["branchid"], out _branchid))
                {
                    Response.Redirect("/login.aspx");
                    return;
                }

            }



            if (!Page.IsPostBack)
            {


                var branch = db.BranchMasters.FirstOrDefault(o => o.branch_id == _branchid);
                if (branch == null)
                {
                    Response.Redirect("/BranchList.aspx");
                    return;
                }
                else
                {
                    txtBranchCode.Text = branch.branch_code.ToString();
                    txtBranchName.Text = branch.branch_name;
                }



            }


        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            BranchMaster b = db.BranchMasters.FirstOrDefault(o => o.branch_id == _branchid);


            b.branch_code = Convert.ToInt32(txtBranchCode.Text.Trim());
            b.branch_name = txtBranchName.Text.Trim();

            db.SaveChanges();

            Response.Redirect("/BranchList.aspx");
        }
    }
}