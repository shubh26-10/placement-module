﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class LogIn : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void login_btn_Click(object sender, EventArgs e)
        {
            var user = db.UserTbls.FirstOrDefault(o => o.UserName == txtUsername.Text.Trim());
            if (user != null)
            {
                if (user.Password == txtpassword.Text.Trim())
                {
                    Session[AppConst.UserId] = user.UserID;
                    Session["College_Id"] = user.CollegeID;
                    if (user.IsPrincipal != null && user.IsPrincipal == true)
                    {
                        Response.Redirect("PrincipalDashboard.aspx");
                    }
                    else if (user.IsTPO != null && user.IsTPO == true)
                    {
                        Response.Redirect("TpoDashboard.aspx");
                    }
                    if (user.IsDTE != null && user.IsDTE == true)
                    {
                        Response.Redirect("DteDashboard.aspx");
                    }
                    else
                    {
                        Response.Redirect("Dashboard.aspx");
                    }
                }
            }


        }
    }
}