﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class CompanyEdit : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        int _companyid = 0;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }

            if (Request.QueryString["companyid"] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            else
            {
                if (!int.TryParse(Request.QueryString["companyid"], out _companyid))
                {
                    Response.Redirect("/login.aspx");
                    return;
                }

            }

            if (!Page.IsPostBack)
            {
                var comp = db.CompanyTbls.FirstOrDefault(o => o.company_id == _companyid);
                if (comp == null)
                {
                    Response.Redirect("/StudentList.aspx");
                    return;
                }
                else
                {

                    txtName.Text = comp.company_name;
                    ddlSector.SelectedValue = comp.sector.ToString();
                    ddlCategory.SelectedValue = comp.category.ToString();
                    if (comp.IsManufacturing != null && comp.IsManufacturing.Value == true)
                    {
                        cbManufacturing.Checked = true;
                    }
                    if (comp.IsServices != null && comp.IsServices.Value == true)
                    {
                        cbServices.Checked = true;
                    }
                    if (comp.IsTrading != null && comp.IsTrading.Value == true)
                    {
                        cbTrading.Checked = true;
                    }
                    txtAddress.Text = comp.address;
                    txtMail.Text = comp.mail_id;
                    txtContact.Text = comp.contact;
                }
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            CompanyTbl c = db.CompanyTbls.FirstOrDefault(o => o.company_id == _companyid);
            c.company_name = txtName.Text.Trim();
            c.sector = ddlSector.SelectedValue;
            c.category = ddlCategory.SelectedValue;
            c.IsManufacturing = cbManufacturing.Checked;
            c.IsServices = cbServices.Checked;
            c.IsTrading = cbTrading.Checked;
            c.address = txtAddress.Text.Trim();
            c.mail_id = txtMail.Text.Trim();
            c.contact = txtContact.Text.Trim();

            db.SaveChanges();

            Response.Redirect("/CompanyList.aspx");

        }
    }
}