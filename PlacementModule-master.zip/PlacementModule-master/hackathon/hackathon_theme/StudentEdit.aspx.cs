﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class StudentEdit : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        int _studentid = 0;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            if (Request.QueryString["studentid"] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            else
            {
                if (!int.TryParse(Request.QueryString["studentid"], out _studentid))
                {
                    Response.Redirect("/login.aspx");
                    return;
                }

            }

            if (!Page.IsPostBack)
            {
                var branchList = db.vw_BranchMaster.OrderBy(o => o.branch_name).ToList();
                ddlBranch.DataSource = branchList;
                ddlBranch.DataBind();

                var collegeCode = db.vw_CollegeMaster.OrderBy(o => o.college_code).ToList();
                ddlCollegeCode.DataSource = collegeCode;
                ddlCollegeCode.DataBind();

                var stud = db.student_master.FirstOrDefault(o => o.student_id == _studentid);
                if (stud == null)
                {
                    Response.Redirect("/StudentList.aspx");
                    return;
                }
                else
                {
                    txtEnroll.Text = stud.stud_enroll.ToString();
                    txtName.Text = stud.stud_name;
                    ddlCollegeCode.SelectedValue = stud.college_code.ToString();
                    ddlGender.SelectedValue = stud.gender.ToString();
                    ddlBranch.SelectedValue = stud.branch.ToString();
                    txtAddress.Text = stud.address;
                    txtEmail.Text = stud.email;
                    txtCurrentSem.Text = stud.current_sem.ToString();
                    txtSsc.Text = stud.ssc_marks.ToString();
                    txtHsc.Text = stud.hsc_marks.ToString();
                    txt1SemSpi.Text = stud.sem_1_spi.ToString();
                    txt2SemSpi.Text = stud.sem_2_spi.ToString();
                    txt3SemSpi.Text = stud.sem_3_spi.ToString();
                    txt4SemSpi.Text = stud.sem_4_spi.ToString();
                    txt5SemSpi.Text = stud.sem_5_spi.ToString();
                    txt6SemSpi.Text = stud.sem_6_spi.ToString();
                    ddlBatch.SelectedValue = stud.Batch.ToString();

                }

            }




        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            student_master s = db.student_master.FirstOrDefault(o => o.student_id == _studentid);

            s.stud_enroll = txtEnroll.Text.Trim();
            s.stud_name = txtName.Text.Trim();
            s.college_code = Convert.ToInt32(ddlCollegeCode.SelectedValue);
            s.gender = ddlGender.SelectedValue;
            s.branch = ddlBranch.SelectedValue;
            s.address = txtAddress.Text.Trim();
            s.email = txtEmail.Text.Trim();
            s.current_sem = Convert.ToInt32(txtCurrentSem.Text.Trim());
            s.ssc_marks = Convert.ToDecimal(txtSsc.Text.Trim());
            s.hsc_marks = Convert.ToDecimal(txtHsc.Text.Trim());
            s.sem_1_spi = Convert.ToDecimal(txt1SemSpi.Text.Trim());
            s.sem_2_spi = Convert.ToDecimal(txt2SemSpi.Text.Trim());
            s.sem_3_spi = Convert.ToDecimal(txt3SemSpi.Text.Trim());
            s.sem_4_spi = Convert.ToDecimal(txt4SemSpi.Text.Trim());
            s.sem_5_spi = Convert.ToDecimal(txt5SemSpi.Text.Trim());
            s.sem_6_spi = Convert.ToDecimal(txt6SemSpi.Text.Trim());
            s.Batch = ddlBatch.SelectedValue;



            db.SaveChanges();

            Response.Redirect("/StudentList.aspx");
        }
    }
}