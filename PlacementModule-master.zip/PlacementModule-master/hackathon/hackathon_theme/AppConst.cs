﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace hackathon_theme
{
    public class AppConst
    {
        public const string UserId = "UserId";
    }
}