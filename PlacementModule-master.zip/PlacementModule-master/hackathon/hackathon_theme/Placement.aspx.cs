﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class Placement : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }

            if (!Page.IsPostBack)
            {
                var branchList = db.vw_BranchMaster.OrderBy(o => o.branch_name).ToList();
                ddlBranch.DataSource = branchList;
                ddlBranch.DataBind();


                var companyList = db.CompanyTbls.OrderBy(o => o.company_name).ToList();
                ddlCompany.DataSource = companyList;
                ddlCompany.DataBind();
            }




        }


        protected void btnShow_Click(object sender, EventArgs e)
        {

            var studentList = db.student_master.Where(o =>
                (o.PlacementCompanyId == null || o.PlacementCompanyId == 0)
                && o.branch == ddlBranch.SelectedValue
                && o.Batch == ddlBatch.SelectedValue).ToList();
            gvList.DataSource = studentList;
            gvList.DataBind();

        }


        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int compID = Convert.ToInt32(ddlCompany.SelectedValue);

            foreach (GridViewRow r in gvList.Rows)
            {
                CheckBox chk = r.FindControl("chkSelect") as CheckBox;
                if (chk.Checked)
                {
                    HiddenField hdnStdID = r.FindControl("hdnstdID") as HiddenField;
                    int stdID = Convert.ToInt32(hdnStdID.Value);

                    hackathon_theme.student_master studend = db.student_master.FirstOrDefault(o => o.student_id == stdID);
                    if (studend != null)
                    {
                        studend.PlacementCompanyId = compID;
                        studend.DateOfPlacement = txtDateOfPlacement.Text.Trim();

                        db.SaveChanges();
                    }

                }




            }

            Response.Redirect("/TpoDashboard.aspx");


        }
    }
}