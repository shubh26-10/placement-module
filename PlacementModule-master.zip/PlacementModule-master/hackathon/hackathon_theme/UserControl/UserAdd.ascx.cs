﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme.UserControl
{
    public partial class UserAdd : System.Web.UI.UserControl
    {
        hackathonEntities db = new hackathonEntities();


        private string _listUrl = "";

        public string ListURL
        {
            get { return _listUrl; }
            set
            {
                if (value.Length > 0)
                {
                    _listUrl = value;
                }

            }

        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this._listUrl))
            {
                throw new System.Exception("List URL is missing.");
            }



            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            if (!Page.IsPostBack)
            {
                var collegelist = db.college_master.OrderBy(o => o.name).ToList();
                ddlCollege.DataSource = collegelist;
                ddlCollege.DataBind();
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            UserTbl u = new UserTbl();
            u.UserID = db.UserTbls.Max(o => o.UserID) + 1;
            u.CollegeID = Convert.ToInt32(ddlCollege.SelectedValue);
            u.IsDTE = rdIsDTE.Checked;
            u.IsPrincipal = rdIsPrincipal.Checked;
            u.IsTPO = rdIsTPO.Checked;
            u.Password = txtPassword.Text.Trim();
            u.UserName = txtUserName.Text.Trim();

            db.UserTbls.Add(u);
            db.SaveChanges();

            Response.Redirect(this.ListURL);





        }
    }
}