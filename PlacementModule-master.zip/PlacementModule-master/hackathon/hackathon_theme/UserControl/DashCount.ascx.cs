﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme.UserControl
{
    public partial class DashCount : System.Web.UI.UserControl
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            int userid;

            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            else
            {
                userid = Convert.ToInt32(Session[AppConst.UserId]);
            }
            var user = db.UserTbls.FirstOrDefault(o => o.UserID == userid);

            int? studCount = db.student_master.Max(o => o.student_id);
            lblStudentCount.Text = Convert.ToString(studCount);

            int? compCount = db.CompanyTbls.Max(o => o.company_id);
            lblCompanyCount.Text = Convert.ToString(compCount);


            int? collCount = db.college_master.Max(o => o.college_id);
            lblCollegeCount.Text = Convert.ToString(collCount);

            if (user.IsTPO != null && user.IsTPO == true || user.IsPrincipal != null && user.IsPrincipal == true)
            {

                lblTotalCollege.Visible = false;
                lblCollegeCount.Visible = false;
            }


            int? placeCount = db.student_master.Count(o => o.PlacementCompanyId != null);
            lblPlacementCount.Text = Convert.ToString(placeCount);

            int? ItPlaceCount = db.student_master.Count(o => o.PlacementCompanyId != null && o.branch == "2");
            int? CompPlaceCount = db.student_master.Count(o => o.PlacementCompanyId != null && o.branch == "4");
            int? CivilPlaceCount = db.student_master.Count(o => o.PlacementCompanyId != null && o.branch == "3");
            int? BioTechPlaceCount = db.student_master.Count(o => o.PlacementCompanyId != null && o.branch == "1");
            int? MechPlaceCount = db.student_master.Count(o => o.PlacementCompanyId != null && o.branch == "5");

            //Itplacecountjs.Value = Convert.ToString(ItPlaceCount);
            //CompplaceCountjs.Value = Convert.ToString(CompPlaceCount);
            //CivilplaceCountjs.Value = Convert.ToString(CivilPlaceCount);
            //BioTechplaceCountjs.Value = Convert.ToString(BioTechPlaceCount);
            //MechPlaceCountjs.Value = Convert.ToString(MechPlaceCount);

            //placecount.Text = Convert.ToString(placecountjs.Value);



        }
    }
}