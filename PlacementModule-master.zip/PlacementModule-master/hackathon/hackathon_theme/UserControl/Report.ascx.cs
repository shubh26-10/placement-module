﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme.UserControl
{
    public partial class Report : System.Web.UI.UserControl
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            if (!Page.IsPostBack)
            {
                var branchList = db.vw_BranchMaster.OrderBy(o => o.branch_name).ToList();
                ddlBranch.DataSource = branchList;
                ddlBranch.DataBind();

                var batchList = db.student_master.GroupBy(o => o.Batch).Select(o => o.FirstOrDefault()).ToList();
                ddlBatch.DataSource = batchList;
                ddlBatch.DataBind();

                var companyList = db.CompanyTbls.OrderBy(o => o.company_name).ToList();
                ddlCompany.DataSource = companyList;
                ddlCompany.DataBind();
            }

        }


        protected void btnShow_Click(object sender, EventArgs e)
        {
            var studentList = db.student_master.Where(o =>
                (o.PlacementCompanyId.ToString() == ddlCompany.SelectedValue)
                && o.branch == ddlBranch.SelectedValue
                && o.Batch == ddlBatch.SelectedValue).ToList();
            gvList.DataSource = studentList;
            gvList.DataBind();
        }
    }
}