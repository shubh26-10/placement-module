﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme.UserControl
{
    public partial class UserList : System.Web.UI.UserControl
    {
        hackathonEntities db = new hackathonEntities();
        private string _editUrl = "";


        public string EditURL
        {
            get { return _editUrl; }
            set
            {
                if (value.Length > 0)
                {
                    _editUrl = value;
                }

            }

        }





        protected void Page_Load(object sender, EventArgs e)
        {
            int userid;
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            else
            {
                userid = Convert.ToInt32(Session[AppConst.UserId]);
            }
            var user = db.UserTbls.FirstOrDefault(o => o.UserID == userid);
            //if (user != null)
            //{


            if (user.IsPrincipal != null && user.IsPrincipal == true)
            {
                var userList = db.UserTbls.Where(o => o.IsTPO==true).ToList();
                gvList.DataSource = userList;
                gvList.DataBind();
            }
            
            else if (user.IsDTE != null && user.IsDTE == true)
            {
                var userList = db.UserTbls.OrderBy(o => o.UserName).ToList();
                gvList.DataSource = userList;
                gvList.DataBind();
            }
            else
            {
                var userList = db.UserTbls.OrderBy(o => o.UserName).ToList();
                gvList.DataSource = userList;
                gvList.DataBind();
            }

            //}



        }

        protected void gvList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                UserTbl u = e.Row.DataItem as UserTbl;

                HyperLink editlink = e.Row.FindControl("hlnkEdit") as HyperLink;
                editlink.NavigateUrl = EditURL + "?userid=" + u.UserID.ToString();
            }








        }




    }
}