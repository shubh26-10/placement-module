﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing.Design;

namespace hackathon_theme.UserControl
{
    public partial class UserEdit : System.Web.UI.UserControl
    {
        hackathonEntities db = new hackathonEntities();
        int _userid = 0;

        private string _listUrl = "";

        [Editor("System.Web.UI.Design.UrlEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
        [UrlProperty]
        public string ListURL
        {
            get { return _listUrl; }
            set
            {
                if (value.Length > 0)
                {
                    _listUrl = value;
                }

            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(this._listUrl))
            {
                throw new System.Exception("List URL is missing.");
            }

            if (Request.QueryString["userid"] == null)
            {
                Response.Redirect("UserList.aspx");
                return;
            }
            else
            {
                if (!int.TryParse(Request.QueryString["userid"], out _userid))
                {
                    Response.Redirect("UserList.aspx");
                    return;
                }
            }

            if (!Page.IsPostBack)
            {
                var collegelist = db.college_master.OrderBy(o => o.name).ToList();
                ddlCollege.DataSource = collegelist;
                ddlCollege.DataBind();

                var usr = db.UserTbls.FirstOrDefault(o => o.UserID == _userid);
                if (usr == null)
                {
                    Response.Redirect("/UserList.aspx");
                    return;
                }
                else
                {
                    txtUserName.Text = usr.UserName;
                    txtPassword.Text = usr.Password;
                    if (usr.IsPrincipal != null && usr.IsPrincipal.Value == true)
                    {
                        rdIsPrincipal.Checked = true;
                    }
                    else if (usr.IsTPO != null && usr.IsTPO.Value == true)
                    {
                        rdIsTPO.Checked = true;
                    }
                    else if (usr.IsDTE != null && usr.IsDTE.Value == true)
                    {
                        rdIsDTE.Checked = true;
                    }

                    ddlCollege.SelectedValue = usr.CollegeID.ToString();


                }
            }
        }


        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            UserTbl u = db.UserTbls.FirstOrDefault(o => o.UserID == _userid);

            //u.UserID = db.UserTbls.Max(o => o.UserID) + 1;
            u.CollegeID = Convert.ToInt32(ddlCollege.SelectedValue);
            u.IsDTE = rdIsDTE.Checked;
            u.IsPrincipal = rdIsPrincipal.Checked;
            u.IsTPO = rdIsTPO.Checked;
            u.Password = txtPassword.Text.Trim();
            u.UserName = txtUserName.Text.Trim();

            //db.UserTbls.Add(u);
            db.SaveChanges();

            Response.Redirect(this.ListURL);
        }


    }
}