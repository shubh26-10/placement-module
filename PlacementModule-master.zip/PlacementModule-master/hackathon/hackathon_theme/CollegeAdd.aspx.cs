﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class CollegeAddd : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
        }
            protected void btnAddCollege_Click(object sender, EventArgs e)
        {
            college_master c = new college_master();
            c.college_id = db.college_master.Max(o => o.college_id) + 1;
            c.college_code = Convert.ToInt32(txtCollegeCode.Text.Trim());
            c.name = txtCollegeName.Text.Trim();
            c.type=ddlType.SelectedValue;
            c.address=txtCollegeAddress.Text.Trim();
            c.principal_name=txtPrincipalName.Text.Trim();


            db.college_master.Add(c);
            db.SaveChanges();

            Response.Redirect("/CollegeList.aspx");
        }
    }
}