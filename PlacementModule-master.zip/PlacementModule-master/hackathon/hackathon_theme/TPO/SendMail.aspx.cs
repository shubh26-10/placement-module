﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

namespace hackathon_theme.TPO
{
    public partial class SendMail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblError.Text = "";
        }


        protected void btnSubmit_OnClick(object sender, EventArgs e)
        {
            try
            {
                var smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;
                //X509Certificate cert = 
                System.Net.NetworkCredential credential = new NetworkCredential(
                    txtFrom.Text.Trim(), txtGmailPassword.Text.Trim());

                smtp.Credentials = credential;

                MailMessage msg = new MailMessage();

                msg.From = new MailAddress(txtFrom.Text.Trim());
                msg.To.Add(new MailAddress(txtToAddress.Text.Trim()));
                msg.CC.Add(new MailAddress(txtCcAddress.Text.Trim()));
                msg.Bcc.Add(new MailAddress(txtBccAddress.Text.Trim()));

                msg.Subject = txtSub.Text.Trim();
                msg.Body = txtEmailBody.Text.Trim();
                msg.IsBodyHtml = true;

                smtp.Send(msg);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
            }

        }
    }
}