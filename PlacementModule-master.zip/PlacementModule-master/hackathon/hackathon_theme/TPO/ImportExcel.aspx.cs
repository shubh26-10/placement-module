﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using OfficeOpenXml;

namespace hackathon_theme.TPO
{
    public partial class ImportExcel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblError.Text = "No file uploaded.";
        }

        protected void btnUploadAndImport_OnClick(object sender, EventArgs e)
        {
            if (file1.HasFile == false)
            {
                lblError.Text = "No file uploaded.";
                return;
            }

            var fileTypeList = new List<string>() { "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" };

            var fileType = file1.PostedFile.ContentType;
            if (!fileTypeList.Contains(fileType))
            {
                lblError.Text = "File type does not look like an Excel file.";
                return;
            }

            string fileName = "";
            string filePath = "";

            fileName = System.DateTime.Today.Ticks.ToString();
            fileName = fileName + System.IO.Path.GetExtension(file1.FileName); //98237423987.xls

            filePath = System.IO.Path.Combine(Server.MapPath("~/UploadedFiles")
                                                 , fileName);

            file1.SaveAs(filePath);


            //column indexes
            const int headerRowIndex = 1;
            const int EnrolmentNumberCol = 1;
            const int StudentNameCol = 2;
            const int StudentMobCol = 3;

            FileInfo fi = new FileInfo(filePath);

            List<StudentInfo> students = new List<StudentInfo>();

            using (ExcelPackage excelPackage = new ExcelPackage(fi))
            {
                //Get a WorkSheet by index. Note that EPPlus indexes are base 1, not base 0!
                ExcelWorksheet firstWorksheet = excelPackage.Workbook.Worksheets[1];

                //Get a WorkSheet by name. If the worksheet doesn't exist, throw an exeption
                //ExcelWorksheet namedWorksheet = excelPackage.Workbook.Worksheets["SomeWorksheet"];

                //If you don't know if a worksheet exists, you could use LINQ,
                //So it doesn't throw an exception, but return null in case it doesn't find it
                //ExcelWorksheet anotherWorksheet =excelPackage.Workbook.Worksheets.FirstOrDefault(x => x.Name == "SomeWorksheet");


                int rowIndex = headerRowIndex + 1;
                int lastRowIndex = firstWorksheet.Dimension.End.Row;

                for (; rowIndex <= lastRowIndex; rowIndex++)
                {
                    StudentInfo s = new StudentInfo();
                    s.EnronmentNumber = firstWorksheet.Cells[rowIndex, EnrolmentNumberCol].Value.ToString();
                    s.StudentName = firstWorksheet.Cells[rowIndex, StudentNameCol].Value.ToString();
                    s.MobileNumber = firstWorksheet.Cells[rowIndex, StudentMobCol].Value.ToString();
                    students.Add(s);
                }




                //Get the content from cells A1 and B1 as string, in two different notations
                //string valA1 = firstWorksheet.Cells["A1"].Value.ToString();
                //string valB1 = firstWorksheet.Cells[1, 2].Value.ToString();

                //Save your file
                //excelPackage.Save();
            }

            SaveStudents(students);

            Response.Write("<script>alert('Data inserted successfully')</script>");


        }

        private void SaveStudents(List<StudentInfo> students)
        {
            var conn = new SqlConnection(@"data source=NST-012\SQLEXPRESS_2014;initial catalog=hackathon;user id=OfficeLocal;password=OfficeLocal;MultipleActiveResultSets=True;");
            conn.Open();
            foreach (var s in students)
            {
                string sql = "Insert into ExcelData(EnrolmentNumber,Name,Mob) values(@enlNo,@name,@mob)";
                var cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@enlNo", s.EnronmentNumber);
                cmd.Parameters.AddWithValue("@name", s.StudentName);
                cmd.Parameters.AddWithValue("@mob", s.MobileNumber);
                cmd.ExecuteNonQuery();
            }
            conn.Close();
        }


        private class StudentInfo
        {
            public string EnronmentNumber { get; set; }
            public string StudentName { get; set; }
            public string MobileNumber { get; set; }
        }


    }
}