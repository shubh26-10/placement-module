﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme.TPO
{
    public partial class TpoMaster : System.Web.UI.MasterPage
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_click(object sender, EventArgs e)
        {

            //var _companyname = db.CompanyTbls.FirstOrDefault(o => o.company_name == btnSearch.InnerText);


        }
    }
}