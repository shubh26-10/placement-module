﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class CollegeList : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }

            var collegeList = db.college_master.OrderBy(o => o.name).ToList();
            gvList.DataSource = collegeList;
            gvList.DataBind();
        }
    }
}