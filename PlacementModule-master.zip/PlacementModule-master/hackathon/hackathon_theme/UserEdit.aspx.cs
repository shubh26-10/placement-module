﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class UserEdit : System.Web.UI.Page
    {
        int _userid;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }



            if (Request.QueryString["userid"] == null)
            {
                Response.Redirect("/UserList.aspx");
                return;
            }
            else
            {
                if (!int.TryParse(Request.QueryString["userid"], out _userid))
                {
                    Response.Redirect("/UserList.aspx");
                    return;
                }
            }
        }

    }
}