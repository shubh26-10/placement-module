﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class StudentAdd : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            if (!Page.IsPostBack)
            {
                var branchList = db.vw_BranchMaster.OrderBy(o => o.branch_name).ToList();
                ddlBranch.DataSource = branchList;
                ddlBranch.DataBind();

                var collegeCode = db.vw_CollegeMaster.OrderBy(o => o.college_code).ToList();
                ddlCollegeCode.DataSource = collegeCode;
                ddlCollegeCode.DataBind();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            student_master s = new student_master();


            //int? abcl = db.student_master.Max(o => (int?)o.student_id);



            if (db.student_master.Max(o => (int?)o.student_id) == null)
            {
                s.student_id = 1;
            }
            else
            {
                s.student_id = db.student_master.Max(o => o.student_id) + 1;
            }



            s.college_id = Convert.ToInt32(ddlCollegeCode.SelectedValue);
            s.stud_enroll = txtEnroll.Text.Trim();
            s.stud_name = txtName.Text.Trim();
            s.college_code = Convert.ToInt32(ddlCollegeCode.SelectedValue);
            s.gender = ddlGender.SelectedValue;
            s.branch = ddlBranch.SelectedValue;
            s.address = txtAddress.Text.Trim();
            s.email = txtEmail.Text.Trim();
            s.current_sem = Convert.ToInt32(txtCurrentSem.Text.Trim());
            s.ssc_marks = Convert.ToDecimal(txtSsc.Text.Trim());
            s.hsc_marks = Convert.ToDecimal(txtHsc.Text.Trim());
            s.sem_1_spi = Convert.ToDecimal(txt1SemSpi.Text.Trim());
            s.sem_2_spi = Convert.ToDecimal(txt2SemSpi.Text.Trim());
            s.sem_3_spi = Convert.ToDecimal(txt3SemSpi.Text.Trim());
            s.sem_4_spi = Convert.ToDecimal(txt4SemSpi.Text.Trim());
            s.sem_5_spi = Convert.ToDecimal(txt5SemSpi.Text.Trim());
            s.sem_6_spi = Convert.ToDecimal(txt6SemSpi.Text.Trim());
            s.Batch = ddlBatch.SelectedValue;

            db.student_master.Add(s);
            db.SaveChanges();

            Response.Redirect("/StudentList.aspx");

        }
    }
}