﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class CompanyAdd : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
        }

            protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CompanyTbl c = new CompanyTbl();
            if (db.CompanyTbls.Max(o => (int?)o.company_id) == null)
            {
                c.company_id = 1;
            }
            else
            {
                c.company_id = db.CompanyTbls.Max(o => o.company_id) + 1;
            }
            c.company_name = txtName.Text.Trim();
            c.sector = ddlSector.SelectedValue;
            c.category = ddlCategory.SelectedValue;
            c.IsManufacturing = cbManufacturing.Checked;
            c.IsServices = cbServices.Checked;
            c.IsTrading = cbTrading.Checked;
            c.address = txtAddress.Text.Trim();
            c.mail_id = txtMail.Text.Trim();
            c.contact = txtContact.Text.Trim();
            

            db.CompanyTbls.Add(c);
            db.SaveChanges();

            Response.Redirect("/CompanyList.aspx");
        }
        
    }
}