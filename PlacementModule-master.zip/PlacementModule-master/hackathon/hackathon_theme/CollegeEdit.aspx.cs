﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hackathon_theme
{
    public partial class CollegeEdit : System.Web.UI.Page
    {
        hackathonEntities db = new hackathonEntities();
        int _collegeid = 0;
        protected void Page_Load(object sender, EventArgs e)
        {


            if (Session[AppConst.UserId] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }

            if (Request.QueryString["collegeid"] == null)
            {
                Response.Redirect("/login.aspx");
                return;
            }
            else
            {
                if (!int.TryParse(Request.QueryString["collegeid"], out _collegeid))
                {
                    Response.Redirect("/login.aspx");
                    return;
                }

            }

            if (!Page.IsPostBack)
            {
                var coll = db.college_master.FirstOrDefault(o => o.college_id == _collegeid);
                if (coll == null)
                {
                    Response.Redirect("/CollegeList.aspx");
                    return;
                }
                else
                {

                    txtCollegeCode.Text = coll.college_code.ToString();
                    txtCollegeName.Text = coll.name;
                    ddlType.SelectedValue = coll.type;
                    txtCollegeAddress.Text = coll.address;
                    txtPrincipalName.Text = coll.principal_name;

                }
            }




        }
        protected void btnAddCollege_Click(object sender, EventArgs e)
        {
            college_master c = db.college_master.FirstOrDefault(o => o.college_id == _collegeid);

            c.college_code = Convert.ToInt32(txtCollegeCode.Text.Trim());
            c.name = txtCollegeName.Text.Trim();
            c.type = ddlType.SelectedValue;
            c.address = txtCollegeAddress.Text.Trim();
            c.principal_name = txtPrincipalName.Text.Trim();

            db.SaveChanges();

            Response.Redirect("/CollegeList.aspx");





        }
    }
}